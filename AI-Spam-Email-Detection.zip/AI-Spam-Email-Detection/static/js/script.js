/**
 * SpamShield AI - Client-side Interactive Logic
 */

document.addEventListener('DOMContentLoaded', () => {
  // Bind Password Visibility Toggles
  initPasswordToggles();

  // Bind Client-side Register Form Validation
  initRegisterValidation();

  // Identify active page
  const isIndexPage = !!document.getElementById('emailText');
  const isHistoryPage = !!document.getElementById('historyTableBody');

  if (isIndexPage) {
    initDetectorPage();
  }

  if (isHistoryPage) {
    initHistoryPage();
  }
});

/* ==========================================================================
   Password Visibility Toggle Helper
   ========================================================================== */
function initPasswordToggles() {
  const togglePassBtn = document.getElementById('togglePasswordBtn');
  const passInput = document.getElementById('password');

  if (togglePassBtn && passInput) {
    togglePassBtn.addEventListener('click', () => {
      const isPassword = passInput.getAttribute('type') === 'password';
      passInput.setAttribute('type', isPassword ? 'text' : 'password');
      togglePassBtn.textContent = isPassword ? '🙈' : '👁️';
    });
  }

  const toggleConfirmBtn = document.getElementById('toggleConfirmPasswordBtn');
  const confirmInput = document.getElementById('confirm_password');

  if (toggleConfirmBtn && confirmInput) {
    toggleConfirmBtn.addEventListener('click', () => {
      const isPassword = confirmInput.getAttribute('type') === 'password';
      confirmInput.setAttribute('type', isPassword ? 'text' : 'password');
      toggleConfirmBtn.textContent = isPassword ? '🙈' : '👁️';
    });
  }
}

/* ==========================================================================
   Register Form Validation Helper
   ========================================================================== */
function initRegisterValidation() {
  const registerForm = document.getElementById('registerForm');
  const jsErrorAlert = document.getElementById('jsErrorAlert');

  if (registerForm) {
    registerForm.addEventListener('submit', (e) => {
      const pass = document.getElementById('password').value;
      const confirmPass = document.getElementById('confirm_password').value;

      if (pass.length < 6) {
        e.preventDefault();
        showJsError('Password must be at least 6 characters long.');
        return;
      }

      if (pass !== confirmPass) {
        e.preventDefault();
        showJsError('Password and confirm password do not match.');
        return;
      }
    });
  }

  function showJsError(msg) {
    if (jsErrorAlert) {
      jsErrorAlert.textContent = msg;
      jsErrorAlert.style.display = 'block';
    }
  }
}

/* ==========================================================================
   Detector Page (index.html) Functions
   ========================================================================== */
function initDetectorPage() {
  const emailText = document.getElementById('emailText');
  const detectBtn = document.getElementById('detectBtn');
  const clearBtn = document.getElementById('clearBtn');
  const charCount = document.getElementById('charCount');
  const wordCount = document.getElementById('wordCount');
  const errorAlert = document.getElementById('errorAlert');
  const placeholderResult = document.getElementById('placeholderResult');
  const resultCard = document.getElementById('resultCard');
  const sampleContainer = document.getElementById('samplePills');

  // Input counter update
  emailText.addEventListener('input', () => {
    const text = emailText.value;
    charCount.textContent = `${text.length} chars`;
    
    const words = text.trim() ? text.trim().split(/\s+/).length : 0;
    wordCount.textContent = `${words} words`;

    hideError();
  });

  // Detect Spam Button Event
  detectBtn.addEventListener('click', async () => {
    const text = emailText.value.trim();

    if (!text) {
      showError('Please enter or paste an email message to analyze.');
      return;
    }

    if (text.length < 5) {
      showError('Email text is too short. Please enter a complete message.');
      return;
    }

    setLoading(true);
    hideError();

    try {
      const response = await fetch('/api/predict', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email_text: text })
      });

      if (response.status === 401) {
        window.location.href = '/login';
        return;
      }

      const data = await response.json();

      if (!response.ok || !data.success) {
        showError(data.error || 'Failed to detect spam. Please try again.');
        setLoading(false);
        return;
      }

      displayResult(data.prediction);

    } catch (err) {
      console.error('Error during prediction fetch:', err);
      showError('Network error occurred. Unable to connect to the server.');
    } finally {
      setLoading(false);
    }
  });

  // Clear / Reset Button Event
  clearBtn.addEventListener('click', () => {
    emailText.value = '';
    charCount.textContent = '0 chars';
    wordCount.textContent = '0 words';
    hideError();

    resultCard.style.display = 'none';
    placeholderResult.style.display = 'flex';
  });

  // Load Preset Samples from API
  loadPresetSamples(sampleContainer, emailText);
}

async function loadPresetSamples(container, textarea) {
  if (!container) return;

  try {
    const res = await fetch('/api/samples');
    const data = await res.json();

    if (data.success && data.samples) {
      container.innerHTML = '';
      data.samples.forEach(sample => {
        const pill = document.createElement('button');
        pill.className = `sample-pill ${sample.type === 'spam' ? 'spam-pill' : 'ham-pill'}`;
        pill.textContent = sample.title;
        pill.addEventListener('click', () => {
          textarea.value = sample.text;
          textarea.dispatchEvent(new Event('input'));
          textarea.focus();
        });
        container.appendChild(pill);
      });
    }
  } catch (err) {
    console.error('Failed to load sample emails:', err);
  }
}

function displayResult(pred) {
  const placeholderResult = document.getElementById('placeholderResult');
  const resultCard = document.getElementById('resultCard');
  const badgeContainer = document.getElementById('badgeContainer');
  const confidenceVal = document.getElementById('confidenceVal');
  const progressBarFill = document.getElementById('progressBarFill');
  const probSpamVal = document.getElementById('probSpamVal');
  const probHamVal = document.getElementById('probHamVal');
  const triggerTags = document.getElementById('triggerTags');

  placeholderResult.style.display = 'none';
  resultCard.style.display = 'block';

  if (pred.is_spam) {
    badgeContainer.className = 'prediction-badge badge-spam';
    badgeContainer.innerHTML = '🚨 SPAM EMAIL DETECTED';
    confidenceVal.style.color = '#ef4444';
    progressBarFill.className = 'progress-bar-fill progress-spam';
  } else {
    badgeContainer.className = 'prediction-badge badge-ham';
    badgeContainer.innerHTML = '✅ LEGITIMATE (NOT SPAM)';
    confidenceVal.style.color = '#10b981';
    progressBarFill.className = 'progress-bar-fill progress-ham';
  }

  confidenceVal.textContent = `${pred.confidence}%`;
  progressBarFill.style.width = `${pred.confidence}%`;

  probSpamVal.textContent = `${pred.spam_prob}%`;
  probHamVal.textContent = `${pred.ham_prob}%`;

  triggerTags.innerHTML = '';
  if (pred.risk_triggers && pred.risk_triggers.length > 0) {
    pred.risk_triggers.forEach(word => {
      const tag = document.createElement('span');
      tag.className = 'trigger-tag';
      tag.textContent = word;
      triggerTags.appendChild(tag);
    });
  } else {
    triggerTags.innerHTML = '<span class="no-triggers">No suspicious keywords detected</span>';
  }
}

function setLoading(isLoading) {
  const detectBtn = document.getElementById('detectBtn');
  if (isLoading) {
    detectBtn.disabled = true;
    detectBtn.innerHTML = '<span class="spinner"></span> Analyzing Email...';
  } else {
    detectBtn.disabled = false;
    detectBtn.innerHTML = '🔍 Detect Spam';
  }
}

function showError(msg) {
  const errorAlert = document.getElementById('errorAlert');
  if (errorAlert) {
    errorAlert.textContent = msg;
    errorAlert.style.display = 'block';
  }
}

function hideError() {
  const errorAlert = document.getElementById('errorAlert');
  if (errorAlert) {
    errorAlert.style.display = 'none';
  }
}

/* ==========================================================================
   History Page (history.html) Functions
   ========================================================================== */
let allHistoryData = [];

function initHistoryPage() {
  const searchInput = document.getElementById('searchInput');
  const clearHistoryBtn = document.getElementById('clearHistoryBtn');

  fetchHistory();

  if (searchInput) {
    searchInput.addEventListener('input', (e) => {
      const query = e.target.value.toLowerCase().trim();
      const filtered = allHistoryData.filter(item => 
        item.text.toLowerCase().includes(query) ||
        item.label.toLowerCase().includes(query)
      );
      renderHistoryTable(filtered);
    });
  }

  if (clearHistoryBtn) {
    clearHistoryBtn.addEventListener('click', async () => {
      if (!confirm('Are you sure you want to clear all your prediction history?')) {
        return;
      }

      try {
        const res = await fetch('/api/history', { method: 'DELETE' });
        if (res.status === 401) {
          window.location.href = '/login';
          return;
        }

        const data = await res.json();
        if (data.success) {
          allHistoryData = [];
          renderHistoryTable([]);
        } else {
          alert('Failed to clear history: ' + data.error);
        }
      } catch (err) {
        console.error('Error clearing history:', err);
        alert('Network error while clearing history.');
      }
    });
  }
}

async function fetchHistory() {
  const tableBody = document.getElementById('historyTableBody');
  try {
    const res = await fetch('/api/history');

    if (res.status === 401) {
      window.location.href = '/login';
      return;
    }

    const data = await res.json();

    if (data.success) {
      allHistoryData = data.history;
      renderHistoryTable(allHistoryData);
    }
  } catch (err) {
    console.error('Error fetching history:', err);
    if (tableBody) {
      tableBody.innerHTML = '<tr><td colspan="5" style="text-align: center; color: var(--spam-red);">Failed to load history data.</td></tr>';
    }
  }
}

function renderHistoryTable(data) {
  const tableBody = document.getElementById('historyTableBody');
  const recordCount = document.getElementById('recordCount');

  if (!tableBody) return;

  if (recordCount) {
    recordCount.textContent = `${data.length} records`;
  }

  if (data.length === 0) {
    tableBody.innerHTML = `
      <tr>
        <td colspan="5" style="text-align: center; color: var(--text-muted); padding: 3rem;">
          No prediction history found for your account. Test some emails on the main page!
        </td>
      </tr>
    `;
    return;
  }

  tableBody.innerHTML = data.map(item => `
    <tr>
      <td style="white-space: nowrap; font-size: 0.85rem; color: var(--text-muted);">
        ${item.timestamp}
      </td>
      <td class="text-cell" title="${escapeHtml(item.text)}">
        ${escapeHtml(item.text_snippet)}
      </td>
      <td>
        <span class="badge-sm ${item.is_spam ? 'badge-spam' : 'badge-ham'}">
          ${item.label}
        </span>
      </td>
      <td style="font-weight: 600;">
        ${item.confidence}%
      </td>
      <td style="font-size: 0.85rem; color: var(--text-secondary);">
        ${item.word_count} words
      </td>
    </tr>
  `).join('');
}

function escapeHtml(str) {
  if (!str) return '';
  return str.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#039;");
}
