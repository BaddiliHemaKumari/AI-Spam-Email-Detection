import os
import re
import joblib
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.naive_bayes import MultinomialNB
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score


def preprocess_text(text):
    """
    Clean and preprocess email text using NLP techniques.
    - Convert to lowercase
    - Remove web URLs
    - Remove email addresses
    - Remove non-alphanumeric characters / punctuation
    - Normalize extra whitespaces
    """
    if not isinstance(text, str):
        return ""
    
    text = text.lower()
    # Remove URLs
    text = re.sub(r'https?://\S+|www\.\S+', ' ', text)
    # Remove emails
    text = re.sub(r'\S+@\S+', ' ', text)
    # Remove special characters and numbers (keep letters and spaces)
    text = re.sub(r'[^a-z\s]', ' ', text)
    # Normalize whitespaces
    text = re.sub(r'\s+', ' ', text).strip()
    
    return text


def load_and_clean_data(dataset_path):
    """
    Load CSV, remove missing values and duplicate entries, and preprocess text.
    """
    print(f"Loading dataset from: {dataset_path}")
    if not os.path.exists(dataset_path):
        raise FileNotFoundError(f"Dataset file not found at {dataset_path}")
    
    df = pd.read_csv(dataset_path)
    print(f"Initial raw rows: {len(df)}")
    
    # Handle missing values
    df = df.dropna(subset=['label', 'text'])
    
    # Standardize label column
    df['label'] = df['label'].astype(str).str.strip().str.lower()
    df = df[df['label'].isin(['spam', 'ham'])]
    
    # Remove duplicate text records
    df = df.drop_duplicates(subset=['text'])
    print(f"Cleaned rows after dropna and drop_duplicates: {len(df)}")
    print(f"Label distribution:\n{df['label'].value_counts()}")
    
    # Preprocess text
    df['cleaned_text'] = df['text'].apply(preprocess_text)
    
    # Filter out empty cleaned strings
    df = df[df['cleaned_text'].str.len() > 0]
    
    return df


def train_and_evaluate():
    # Setup paths
    base_dir = os.path.dirname(os.path.abspath(__file__))
    dataset_path = os.path.join(base_dir, 'dataset', 'spam_email_dataset.csv')
    model_dir = os.path.join(base_dir, 'model')
    os.makedirs(model_dir, exist_ok=True)
    
    # Load dataset
    df = load_and_clean_data(dataset_path)
    
    # Map labels: spam -> 1, ham -> 0
    X = df['cleaned_text']
    y = df['label'].map({'spam': 1, 'ham': 0})
    
    # Train-test split (80% train, 20% test)
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.20, random_state=42, stratify=y
    )
    print(f"\nTraining set size: {len(X_train)} | Test set size: {len(X_test)}")
    
    # TF-IDF Feature Extraction
    vectorizer = TfidfVectorizer(
        max_features=3000,
        ngram_range=(1, 2),
        stop_words='english'
    )
    X_train_tfidf = vectorizer.fit_transform(X_train)
    X_test_tfidf = vectorizer.transform(X_test)
    
    print("\n--- Model Evaluation & Comparison ---")
    
    # Candidate 1: Multinomial Naive Bayes
    nb_model = MultinomialNB(alpha=0.1)
    nb_model.fit(X_train_tfidf, y_train)
    nb_preds = nb_model.predict(X_test_tfidf)
    
    nb_metrics = {
        'name': 'Multinomial Naive Bayes',
        'model': nb_model,
        'accuracy': accuracy_score(y_test, nb_preds),
        'precision': precision_score(y_test, nb_preds, zero_division=0),
        'recall': recall_score(y_test, nb_preds, zero_division=0),
        'f1': f1_score(y_test, nb_preds, zero_division=0)
    }
    
    # Candidate 2: Logistic Regression
    lr_model = LogisticRegression(max_iter=1000, C=1.0)
    lr_model.fit(X_train_tfidf, y_train)
    lr_preds = lr_model.predict(X_test_tfidf)
    
    lr_metrics = {
        'name': 'Logistic Regression',
        'model': lr_model,
        'accuracy': accuracy_score(y_test, lr_preds),
        'precision': precision_score(y_test, lr_preds, zero_division=0),
        'recall': recall_score(y_test, lr_preds, zero_division=0),
        'f1': f1_score(y_test, lr_preds, zero_division=0)
    }
    
    # Output comparison table
    models = [nb_metrics, lr_metrics]
    for m in models:
        print(f"\nModel: {m['name']}")
        print(f"  Accuracy : {m['accuracy'] * 100:.2f}%")
        print(f"  Precision: {m['precision'] * 100:.2f}%")
        print(f"  Recall   : {m['recall'] * 100:.2f}%")
        print(f"  F1-Score : {m['f1'] * 100:.2f}%")
        
    # Select best model based on F1 score (and accuracy as tie-breaker)
    best_model_info = max(models, key=lambda x: (x['f1'], x['accuracy']))
    print(f"\n=> Best Selected Model: {best_model_info['name']} (F1-Score: {best_model_info['f1'] * 100:.2f}%)")
    
    # Save best model and vectorizer
    classifier_path = os.path.join(model_dir, 'spam_classifier.pkl')
    vectorizer_path = os.path.join(model_dir, 'tfidf_vectorizer.pkl')
    
    joblib.dump(best_model_info['model'], classifier_path)
    joblib.dump(vectorizer, vectorizer_path)
    
    print(f"Successfully saved classifier to: {classifier_path}")
    print(f"Successfully saved TF-IDF vectorizer to: {vectorizer_path}")


if __name__ == '__main__':
    train_and_evaluate()
