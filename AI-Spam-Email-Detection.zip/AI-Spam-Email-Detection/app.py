import os
import re
import json
import sqlite3
import joblib
from datetime import datetime
from functools import wraps
from flask import Flask, render_template, request, jsonify, redirect, url_for, session, flash
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__)
app.secret_key = os.environ.get('SECRET_KEY', 'spamshield_secure_key_2026_v9x7')

# Constants & Directory Paths
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
MODEL_DIR = os.path.join(BASE_DIR, 'model')
DATABASE_DIR = os.path.join(BASE_DIR, 'database')
CLASSIFIER_PATH = os.path.join(MODEL_DIR, 'spam_classifier.pkl')
VECTORIZER_PATH = os.path.join(MODEL_DIR, 'tfidf_vectorizer.pkl')
DB_PATH = os.path.join(DATABASE_DIR, 'users.db')

# Ensure required directories exist
os.makedirs(MODEL_DIR, exist_ok=True)
os.makedirs(DATABASE_DIR, exist_ok=True)

# Global variables for loaded model artifacts
classifier = None
vectorizer = None


def get_db_connection():
    """Establish connection to SQLite database."""
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    """Create database tables automatically if they do not exist."""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    # Users table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            email TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    
    # Predictions table (linked to user_id)
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS predictions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            email_text TEXT NOT NULL,
            prediction TEXT NOT NULL,
            confidence REAL,
            spam_prob REAL,
            ham_prob REAL,
            risk_triggers TEXT,
            word_count INTEGER,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE
        )
    ''')
    
    conn.commit()
    conn.close()
    print("Database tables initialized successfully.")


# Initialize database schema
init_db()


def preprocess_text(text):
    """Clean and preprocess email text matching training pipeline."""
    if not isinstance(text, str):
        return ""
    text = text.lower()
    text = re.sub(r'https?://\S+|www\.\S+', ' ', text)
    text = re.sub(r'\S+@\S+', ' ', text)
    text = re.sub(r'[^a-z\s]', ' ', text)
    text = re.sub(r'\s+', ' ', text).strip()
    return text


def load_model_artifacts():
    """Load saved classifier and TF-IDF vectorizer."""
    global classifier, vectorizer
    if not os.path.exists(CLASSIFIER_PATH) or not os.path.exists(VECTORIZER_PATH):
        print("Model artifacts missing! Initiating auto-training...")
        from train_model import train_and_evaluate
        train_and_evaluate()
    
    classifier = joblib.load(CLASSIFIER_PATH)
    vectorizer = joblib.load(VECTORIZER_PATH)
    print("Successfully loaded trained classifier and TF-IDF vectorizer!")


# Load ML model on startup
load_model_artifacts()


def extract_risk_indicators(text):
    """Extract suspicious spam trigger words found in the text."""
    spam_triggers = {
        'urgent', 'verify', 'account', 'bank', 'locked', 'suspended', 'click', 'link',
        'password', 'security', 'alert', 'winner', 'won', 'prize', 'gift', 'card',
        'claim', 'cash', 'crypto', 'bitcoin', 'deposit', 'free', 'money', 'guaranteed',
        'offer', 'discount', 'refund', 'tax', 'ssn', 'ssn/credit', 'credit', 'loan',
        'refinance', 'prescriptive', 'pill', 'bonus', 'casino', 'lottery', 'wire',
        'transfer', 'payout', 'congratulations', 'congrats', 'expire', 'action required',
        'instant', 'cheap'
    }
    words = re.findall(r'\b[a-z]+\b', text.lower())
    return sorted(list(set(words).intersection(spam_triggers)))


# Auth Decorators
def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            if request.path.startswith('/api/'):
                return jsonify({'success': False, 'error': 'Unauthorized access. Please log in.'}), 401
            return redirect(url_for('login', next=request.url))
        return f(*args, **kwargs)
    return decorated_function


# Authentication Routes
@app.route('/login', methods=['GET', 'POST'])
def login():
    if 'user_id' in session:
        return redirect(url_for('index'))

    error = None
    if request.method == 'POST':
        email = request.form.get('email', '').strip().lower()
        password = request.form.get('password', '')

        if not email or not password:
            error = 'Please enter both email and password.'
        else:
            conn = get_db_connection()
            user = conn.execute('SELECT * FROM users WHERE email = ?', (email,)).fetchone()
            conn.close()

            if user and check_password_hash(user['password'], password):
                session['user_id'] = user['id']
                session['user_name'] = user['name']
                session['user_email'] = user['email']
                return redirect(url_for('index'))
            else:
                error = 'Invalid email or password.'

    return render_template('login.html', error=error)


@app.route('/register', methods=['GET', 'POST'])
def register():
    if 'user_id' in session:
        return redirect(url_for('index'))

    error = None
    success = None
    if request.method == 'POST':
        name = request.form.get('name', '').strip()
        email = request.form.get('email', '').strip().lower()
        password = request.form.get('password', '')
        confirm_password = request.form.get('confirm_password', '')

        # Validations
        email_regex = r'^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$'

        if not name or not email or not password or not confirm_password:
            error = 'All fields are required.'
        elif not re.match(email_regex, email):
            error = 'Please enter a valid email address.'
        elif len(password) < 6:
            error = 'Password must be at least 6 characters long.'
        elif password != confirm_password:
            error = 'Password and confirm password do not match.'
        else:
            conn = get_db_connection()
            existing_user = conn.execute('SELECT id FROM users WHERE email = ?', (email,)).fetchone()

            if existing_user:
                error = 'An account with this email address already exists.'
                conn.close()
            else:
                hashed_pw = generate_password_hash(password)
                conn.execute(
                    'INSERT INTO users (name, email, password) VALUES (?, ?, ?)',
                    (name, email, hashed_pw)
                )
                conn.commit()
                conn.close()
                flash('Registration successful! Please log in.', 'success')
                return redirect(url_for('login'))

    return render_template('register.html', error=error, success=success)


@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('login'))


# Protected Application Pages
@app.route('/')
@login_required
def index():
    return render_template('index.html', user_name=session.get('user_name', 'User'))


@app.route('/history')
@login_required
def history():
    return render_template('history.html', user_name=session.get('user_name', 'User'))


# API Endpoints (Protected)
@app.route('/api/predict', methods=['POST'])
@login_required
def predict():
    try:
        data = request.get_json(silent=True) or {}
        email_text = data.get('email_text', '')

        if not email_text or not isinstance(email_text, str):
            return jsonify({'success': False, 'error': 'Please enter or paste an email message to analyze.'}), 400

        cleaned_input = email_text.strip()
        if len(cleaned_input) == 0:
            return jsonify({'success': False, 'error': 'Email message cannot be empty or contain only whitespace.'}), 400

        if len(cleaned_input) < 5:
            return jsonify({'success': False, 'error': 'Email message is too short for meaningful spam analysis (minimum 5 characters).'}), 400

        preprocessed = preprocess_text(cleaned_input)
        if len(preprocessed) == 0:
            return jsonify({'success': False, 'error': 'The provided text does not contain valid alphabetic words.'}), 400

        # Vectorize & Classify
        vectorized_text = vectorizer.transform([preprocessed])
        pred_label_code = classifier.predict(vectorized_text)[0]
        probabilities = classifier.predict_proba(vectorized_text)[0]

        classes = list(classifier.classes_)
        spam_idx = classes.index(1) if 1 in classes else 1
        ham_idx = classes.index(0) if 0 in classes else 0

        spam_prob = float(probabilities[spam_idx])
        ham_prob = float(probabilities[ham_idx])

        is_spam = bool(pred_label_code == 1)
        label_text = "Spam" if is_spam else "Not Spam"
        confidence = round((spam_prob if is_spam else ham_prob) * 100, 2)
        triggers = extract_risk_indicators(cleaned_input)
        triggers_json = json.dumps(triggers)
        word_count = len(cleaned_input.split())

        user_id = session['user_id']
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

        # Insert prediction record into SQLite database for logged-in user
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute('''
            INSERT INTO predictions (user_id, email_text, prediction, confidence, spam_prob, ham_prob, risk_triggers, word_count)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        ''', (user_id, cleaned_input, label_text, confidence, round(spam_prob * 100, 2), round(ham_prob * 100, 2), triggers_json, word_count))
        
        pred_id = cursor.lastrowid
        conn.commit()
        conn.close()

        history_item = {
            'id': pred_id,
            'timestamp': timestamp,
            'text': cleaned_input,
            'text_snippet': cleaned_input[:120] + ('...' if len(cleaned_input) > 120 else ''),
            'label': label_text,
            'is_spam': is_spam,
            'confidence': confidence,
            'spam_prob': round(spam_prob * 100, 2),
            'ham_prob': round(ham_prob * 100, 2),
            'word_count': word_count,
            'risk_triggers': triggers
        }

        return jsonify({'success': True, 'prediction': history_item})

    except Exception as e:
        print(f"Error processing prediction request: {str(e)}")
        return jsonify({'success': False, 'error': f'Internal server error occurred: {str(e)}'}), 500


@app.route('/api/history', methods=['GET'])
@login_required
def get_history():
    user_id = session['user_id']
    conn = get_db_connection()
    rows = conn.execute('''
        SELECT * FROM predictions 
        WHERE user_id = ? 
        ORDER BY id DESC
    ''', (user_id,)).fetchall()
    conn.close()

    history_data = []
    for r in rows:
        triggers = []
        if r['risk_triggers']:
            try:
                triggers = json.loads(r['risk_triggers'])
            except Exception:
                triggers = []
        
        is_spam = (r['prediction'] == "Spam")
        text = r['email_text']

        history_data.append({
            'id': r['id'],
            'timestamp': str(r['created_at']),
            'text': text,
            'text_snippet': text[:120] + ('...' if len(text) > 120 else ''),
            'label': r['prediction'],
            'is_spam': is_spam,
            'confidence': r['confidence'],
            'spam_prob': r['spam_prob'],
            'ham_prob': r['ham_prob'],
            'word_count': r['word_count'] or len(text.split()),
            'risk_triggers': triggers
        })

    return jsonify({
        'success': True,
        'count': len(history_data),
        'history': history_data
    })


@app.route('/api/history', methods=['DELETE'])
@login_required
def clear_history():
    try:
        user_id = session['user_id']
        conn = get_db_connection()
        conn.execute('DELETE FROM predictions WHERE user_id = ?', (user_id,))
        conn.commit()
        conn.close()
        return jsonify({'success': True, 'message': 'Prediction history cleared successfully.'})
    except Exception as e:
        return jsonify({'success': False, 'error': f'Failed to clear history: {str(e)}'}), 500


@app.route('/api/samples', methods=['GET'])
def get_samples():
    samples = [
        {
            'title': '🚨 Bank Phishing Alert',
            'type': 'spam',
            'text': 'URGENT: Your bank account has been locked due to suspicious activity. Click here http://bit.ly/secure-bank-login to verify your credentials immediately or your funds will be frozen!'
        },
        {
            'title': '🎁 Fake Prize Announcement',
            'type': 'spam',
            'text': 'CONGRATULATIONS! You have won a $1,000 Amazon Gift Card! Claim your prize now at http://win-free-rewards.com/claim before it expires in 2 hours!'
        },
        {
            'title': '⚡ Crypto Giveaway Scam',
            'type': 'spam',
            'text': 'Hot crypto offer! Double your Bitcoin in 24 hours guaranteed! Deposit now to wallet 1A1zP1eP5QGefi2DMPTfTL5SLmv7DivfNa to participate in the mega giveaway.'
        },
        {
            'title': '💼 Team Status Meeting (Legitimate)',
            'type': 'ham',
            'text': 'Hi Sarah, please find attached the revised financial report for Q3. Let me know if you have any questions before our sync at 2 PM.'
        },
        {
            'title': '🍱 Lunch Invite (Legitimate)',
            'type': 'ham',
            'text': 'Hey Mark, are we still meeting for lunch today at 12:30? Let me know if the cafeteria works for you.'
        },
        {
            'title': '🚀 Project Release Update (Legitimate)',
            'type': 'ham',
            'text': 'Hi Andrew, I reviewed the PR for the authentication bug fix. Left a few minor comments on GitHub, otherwise code looks clean.'
        }
    ]
    return jsonify({'success': True, 'samples': samples})


if __name__ == '__main__':
    port = int(os.environ.get('PORT', 5000))
    print(f"\n🚀 SpamShield AI Web Server starting on http://127.0.0.1:{port}")
    app.run(host='0.0.0.0', port=port, debug=True)
