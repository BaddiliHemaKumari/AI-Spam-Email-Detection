# AI-Based Spam Email Detection System with User Authentication

An end-to-end Machine Learning web application for classifying email messages as **Spam** or **Not Spam (Ham)**. Features automated text preprocessing, TF-IDF vectorization, candidate model evaluation (Multinomial Naive Bayes vs. Logistic Regression), automated best model export, SQLite database user registration, Werkzeug password hashing, session authentication, and user-isolated prediction history logs.

---

## 📁 Project Structure

```
AI-Spam-Email-Detection/
│
├── database/
│   └── users.db               # SQLite database for user accounts & user-isolated predictions
│
├── dataset/
│   └── spam_email_dataset.csv # Labeled spam and ham email dataset
│
├── model/
│   ├── spam_classifier.pkl    # Serialized machine learning classifier
│   └── tfidf_vectorizer.pkl   # Fitted TF-IDF vectorizer
│
├── templates/
│   ├── login.html             # Glassmorphism Login page with password show/hide
│   ├── register.html          # User Registration page with validation
│   ├── index.html             # Main Spam Detector dashboard
│   └── history.html           # Prediction History Log dashboard
│
├── static/
│   ├── css/
│   │   └── style.css          # Dark-mode glassmorphism design system
│   └── js/
│       └── script.js          # Interactive UI, AJAX calls & password toggles
│
├── app.py                     # Flask web backend, SQLite DB manager & REST APIs
├── train_model.py             # NLP preprocessing, training & model comparison script
├── requirements.txt           # Required Python packages
├── README.md                  # Complete documentation and setup guide
└── .gitignore                 # Git ignore rules
```

---

## ⚙️ Key Features

1. **User Authentication System**:
   - Registration with Full Name, Email, Password, and Confirm Password fields.
   - Werkzeug secure password hashing (`generate_password_hash` & `check_password_hash`).
   - Session-based access control with `@login_required` decorator.
   - Show/Hide Password interactive toggle.
   - Instant Logout functionality.
2. **User-Isolated Prediction History**:
   - Each logged-in user has their own persistent prediction history stored in SQLite (`database/users.db`).
   - Users cannot see or clear other users' scan histories.
3. **Local AI Classifier**:
   - Runs 100% locally with Scikit-Learn (No paid third-party AI APIs required).
   - Evaluates Multinomial Naive Bayes and Logistic Regression automatically picking the top model.
4. **Modern Dark UI**:
   - Dark mode glassmorphism UI with vibrant colors, confidence gauges, risk trigger badges, and one-click sample emails.

---

## 🛠️ Step-by-Step Setup & Installation Guide

### 1. Open Project Directory
Navigate to the project folder:
```bash
cd AI-Spam-Email-Detection
```

### 2. Create & Activate Virtual Environment

- **On Windows (PowerShell / Command Prompt)**:
  ```powershell
  python -m venv venv
  .\venv\Scripts\activate
  ```

- **On macOS / Linux**:
  ```bash
  python3 -m venv venv
  source venv/bin/activate
  ```

### 3. Install Dependencies
```bash
pip install -r requirements.txt
```

### 4. Train the ML Model
```bash
python train_model.py
```

### 5. Launch the Application
```bash
python app.py
```

Open your browser and navigate to:
```
http://127.0.0.1:5000
```

---

## 🧪 Testing User Flows

1. **Accessing Protected Routes**:
   - Go to `http://127.0.0.1:5000/`. You will be automatically redirected to `http://127.0.0.1:5000/login`.

2. **Register a New Account**:
   - Click **Register here**.
   - Enter Full Name: `Alice Smith`, Email: `alice@example.com`, Password: `password123`.
   - Submit form -> Redirects to Login page with a success alert.

3. **Login**:
   - Enter Email: `alice@example.com` and Password: `password123`.
   - Click **Sign In** -> Redirects to the Spam Detector dashboard showing `👋 Hi, Alice Smith`.

4. **Detect Spam**:
   - Click one of the preset sample pills (e.g. 🚨 *Bank Phishing Alert*).
   - Click **Detect Spam**.
   - View results: **SPAM EMAIL DETECTED** with confidence score & trigger words.

5. **View History**:
   - Click **History** in the navigation bar to see predictions logged under Alice's account.

6. **Logout & User Isolation**:
   - Click **Logout** in the navigation bar -> Redirects to `/login`.
   - Register a second user `Bob` (`bob@example.com`).
   - Log in as Bob -> Bob's History page starts empty, isolated from Alice's history.
